# Compra en Bailén Admin

Panel de administración conectado a Supabase usando Next.js 14.