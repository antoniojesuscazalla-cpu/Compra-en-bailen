export default function Home() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Bienvenido a Compra en Bailén</h1>
      <p>Conectado con Supabase correctamente ✅</p>
    </main>
  );
}
