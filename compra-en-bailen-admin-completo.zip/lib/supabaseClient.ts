import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://dwkjecpsqxzkrgxmwuns.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsImlhdCI6MTc2Mjc1OTEyMCwiZXhwIjoyMDc4MzM1MTIwfQ.-adnqS-Ki7BQaRzxMV-y1FlZnyRCQAvh85KXoYCTlmw';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
